$ErrorActionPreference = 'Stop'

$campaignId = 'm4-technical-20260926-v1'
$campaignRoot = 'D:\Argos-m4-technical-20260926-v1'
$repository = 'D:\Argos-m4-prospective-v8'
$expectedRevision = '7b75006c6adb1f01d84ab675e46960d47c12cc64'
$uv = 'C:\Users\dacan\AppData\Local\Programs\Python\Python313\Scripts\uv.exe'
$tokenIds = @(
    '1910830010387565971650098373488592514702818137344973088263643820608151819241',
    '55115078421062885512539156303747803058407616201213034911037320915726138659123'
)
$statusPath = Join-Path $campaignRoot 'runner.status.json'
$logPath = Join-Path $campaignRoot 'runner.log'
$errorLogPath = Join-Path $campaignRoot 'runner.err.log'
$activeScenario = $null
$completed = @()

function Write-RunnerStatus([string]$state, [string]$reason = '') {
    $record = [ordered]@{
        campaign_id = $campaignId
        code_revision = $expectedRevision
        state = $state
        active_scenario = $activeScenario
        completed_scenarios = @($completed)
        owner_pid = $PID
        updated_at = [DateTime]::UtcNow.ToString('o')
        reason = if ($reason) { $reason } else { $null }
    }
    $record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $statusPath -Encoding UTF8
}

function Add-RunnerLog([string]$message) {
    Add-Content -LiteralPath $logPath -Value ('{0} {1}' -f [DateTime]::UtcNow.ToString('o'), $message)
}

try {
    Set-Location -LiteralPath $repository
    $revision = (& git rev-parse HEAD).Trim()
    if ($LASTEXITCODE -ne 0 -or $revision -ne $expectedRevision) {
        throw "repository revision differs from $expectedRevision"
    }
    $dirty = & git status --porcelain=v1
    if ($LASTEXITCODE -ne 0 -or $dirty) {
        throw 'repository working tree is not clean'
    }
    if (-not (Test-Path -LiteralPath $uv -PathType Leaf)) {
        throw "uv executable missing: $uv"
    }

    Set-Content -LiteralPath (Join-Path $campaignRoot 'runner.pid') -Value $PID -Encoding ASCII
    Add-RunnerLog "owner started pid=$PID revision=$revision"
    Write-RunnerStatus 'RUNNING'

    $steps = @(
        [pscustomobject]@{ Name = 'T1'; Command = 'run-t1'; Scenario = ''; Tokens = $true },
        [pscustomobject]@{ Name = 'T2'; Command = 'run-t2'; Scenario = ''; Tokens = $true },
        [pscustomobject]@{ Name = 'T3'; Command = 'run-t3'; Scenario = ''; Tokens = $true },
        [pscustomobject]@{ Name = 'T4'; Command = 'run-fault'; Scenario = 'T4_NETWORK_INTERRUPTION'; Tokens = $false },
        [pscustomobject]@{ Name = 'T5'; Command = 'run-fault'; Scenario = 'T5_PROCESS_INTERRUPTION'; Tokens = $false },
        [pscustomobject]@{ Name = 'T6'; Command = 'run-fault'; Scenario = 'T6_STORAGE_INTERRUPTION'; Tokens = $false },
        [pscustomobject]@{ Name = 'T7'; Command = 'run-t7'; Scenario = ''; Tokens = $false },
        [pscustomobject]@{ Name = 'T8'; Command = 'run-t8'; Scenario = ''; Tokens = $false }
    )

    foreach ($step in $steps) {
        $activeScenario = $step.Name
        $output = Join-Path $campaignRoot $step.Name.ToLowerInvariant()
        if (Test-Path -LiteralPath $output) {
            throw "output already exists: $output"
        }
        $scenarioArgs = @(
            'run', 'python', 'scripts/m4_technical_campaign.py', $step.Command,
            '--campaign-id', $campaignId, '--output', $output,
            '--repository', $repository
        )
        if ($step.Tokens) {
            foreach ($tokenId in $tokenIds) {
                $scenarioArgs += @('--token-id', $tokenId)
            }
        }
        if ($step.Scenario) {
            $scenarioArgs += @('--scenario', $step.Scenario)
        }
        if ($step.Name -eq 'T8') {
            $scenarioArgs += @(
                '--c-root', 'C:\Users\dacan\AppData\Local\Temp\argos-m4-technical-20260926-v1-t8',
                '--d-root', (Join-Path $campaignRoot 't8-d-workspace')
            )
        }
        Add-RunnerLog "$($step.Name) started"
        Write-RunnerStatus 'RUNNING'
        & $uv @scenarioArgs 1>> $logPath 2>> $errorLogPath
        $scenarioExitCode = $LASTEXITCODE
        $resultFiles = @(Get-ChildItem -LiteralPath $output -File -Filter '*result.json' -ErrorAction SilentlyContinue)
        if ($scenarioExitCode -ne 0 -or $resultFiles.Count -ne 1) {
            throw "$($step.Name) command exited $scenarioExitCode with $($resultFiles.Count) result files"
        }
        $result = Get-Content -LiteralPath $resultFiles[0].FullName -Raw | ConvertFrom-Json
        if ($result.campaign_id -ne $campaignId -or $result.status -ne 'PASSED') {
            throw "$($step.Name) result is not PASSED for this campaign"
        }
        $completed += $step.Name
        Add-RunnerLog "$($step.Name) PASSED"
        $activeScenario = $null
        Write-RunnerStatus 'RUNNING'
    }

    Write-RunnerStatus 'PASSED'
    Add-RunnerLog 'campaign PASSED'
    exit 0
}
catch {
    $failure = $_.Exception.Message
    Add-RunnerLog "campaign FAILED: $failure"
    Write-RunnerStatus 'FAILED' $failure
    exit 1
}
