# Riepilogo campagna tecnica M4

- Campagna: `m4-technical-20260926-v1`
- Esito runner: `PASSED`
- Revisione codice: `7b75006c6adb1f01d84ab675e46960d47c12cc64`
- Inizio: `2026-09-26T08:56:25.832456Z` (T1)
- Fine: `2026-09-26T17:06:37.076961Z` (T8)
- Sequenza: T1–T8, senza sovrapposizioni; tutti i risultati sono `PASSED`.
- Limitazioni dichiarate: nessuna nei risultati scenario.

## Risultati

| Test | Scenario | Esito | Durata | Frame | File risultato | SHA-256 risultato | SHA-256 configurazione |
|---|---|---:|---:|---:|---|---|---|
| T1 | `T1_FUNCTIONAL` | PASSED | 553,127 s (limite 600 s) | 128 | `t1/t1-result.json` | `c79e15b82af141d22585d095d60c7094f819765afefabb18ab2f466414f6a458` | `9e0ea19f57ad2b77e1cf87a8ed8c683a2737612f9324ba836b3acfb785806990` |
| T2 | `T2_STABILITY` | PASSED | 7143,475 s (limite 7200 s) | 1764 | `t2/t2-result.json` | `7d045f3b0b7b117f13135bbe5b4fa17ca5c04640c2da531cda0bffbe1a5932ee` | `3b427f705e069ceffe2322c939435af97539879c34c4ab372a11d80242ca9693` |
| T3 | `T3_ENDURANCE` | PASSED | 21544,384 s (limite 21600 s) | 5358 | `t3/t3-result.json` | `8fecb253a27a4e965f3c4e5e0d739942e0350619b0e33bea9103fbe7d4d1a975` | `c33b156fe7b916bb99e870df30418e7cf1f8dd4dbe922cad8aef53acd5555ca8` |
| T4 | `T4_NETWORK_INTERRUPTION` | PASSED | 0,114 s | 0 | `t4/t4_network_interruption-result.json` | `20de3daee2388567b15898ada74b231f8c7a2a6ee8acb34a17da98ac13323ca2` | `10c00b1ab4f1d619a33f0adc44ed8f367cc5d1b183bbe79ecb2c16b158c95707` |
| T5 | `T5_PROCESS_INTERRUPTION` | PASSED | 0,869 s | 0 | `t5/t5_process_interruption-result.json` | `f452b2c4fce5ada16c83ed8dc84474626ab1a263c151acaf1b9d95e4f7fe1d86` | `e08e6a85e8b17a0d5a67b996a8ff03f629db719189b86147bccc07312c0b2ad1` |
| T6 | `T6_STORAGE_INTERRUPTION` | PASSED | 0,073 s | 0 | `t6/t6_storage_interruption-result.json` | `a9a796761beea4e07232846364c3a502153425ed6c12f2e27f439b961d27e998` | `327e75fbced8ea4338ba231e499c39ec761de8bab75cca16906b97a156ae8bc2` |
| T7 | `T7_TERMINAL_SIMULATION` | PASSED | 0,048 s | 0 | `t7/t7_terminal_simulation-result.json` | `c59ba0d2f61902848823ff26186e1f8975180598767dac4ef4b009cd9ba51078` | `fcb2e1571a455cb49bff7061c2345b710f510f6e8e650a5337011273f8647124` |
| T8 | `T8_CROSS_VOLUME` | PASSED | 0,087 s | 0 | `t8/t8_cross_volume-result.json` | `c9588242e50ff101007b87726d65c80b69a1b52085666635dd32b8ff48b23b74` | `648c93c346cf0eb0e8202c78ed5035b304d302ce4126812754af86f516522616` |

## Controlli indipendenti

- I file risultato e configurazione sono presenti una sola volta per scenario; ID campagna e revisione coincidono con il run congelato.
- Le date di inizio/fine rispettano l'ordine T1–T8 e i limiti di durata configurati.
- Gli SHA-256 degli artefatti locali dichiarati nei risultati corrispondono ai file conservati.
- T1: cattura completata, nessun rifiuto, database invariato nelle due replay e digest replay identici.
- T2: 120 campioni; intervallo massimo 62,409 s (limite 120 s); RSS massimo 98.017.280 byte (limite 536.870.912); artefatti massimi 14.145.970 byte (limite 2.147.483.648); conteggi loop/store concordi.
- T3: 73 checkpoint consecutivi da 0 a 72; catena e indice coerenti; intervallo massimo 302,176 s (limite 600 s); 5.358 frame e payload raw; stato terminale ricaricabile verificato.
- T4–T6: fault deterministico attivato una volta e ripresa dello stesso ordinal verificata.
- T7: gli stati `unknown`, `proposed`, `disputed`, `final` e `administrative close` sono stati gestiti nell'ordine congelato.
- T8: fixture C: e D: conservate; identità semantica e contenuto SHA-256 uguali.
- `runner.err.log` è vuoto; `runner.status.json` registra tutti gli otto scenari completati e stato `PASSED`.

## Interpretazione

Il run dimostra il superamento della matrice tecnica T1–T8 sulla revisione indicata. È una qualifica tecnica del percorso di acquisizione, persistenza, ripresa e replay; da solo non valuta la calibrazione predittiva e non costituisce un esito di performance M4.

Gli artefatti originali restano nei rispettivi percorsi `t1/`–`t8/`. Questo riepilogo li indicizza tramite percorso relativo e hash e non li sostituisce.
